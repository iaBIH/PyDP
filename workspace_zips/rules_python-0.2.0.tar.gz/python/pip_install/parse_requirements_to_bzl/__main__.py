"""Main entry point."""
from python.pip_install.parse_requirements_to_bzl import main

if __name__ == "__main__":
    main()
