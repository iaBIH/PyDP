from python.pip_install.parse_requirements_to_bzl.extract_single_wheel import main

if __name__ == "__main__":
    main()
