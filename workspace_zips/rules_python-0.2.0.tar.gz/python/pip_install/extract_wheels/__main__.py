"""Main entry point."""
from python.pip_install.extract_wheels import main

if __name__ == "__main__":
    main()
